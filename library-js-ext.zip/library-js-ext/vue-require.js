/*
 * css-parse.js
 *
 * Distributed under terms of the MIT license.
 */

/*
 * vue.js
 *
 * Distributed under terms of the MIT license.
 */

if("object"==typeof module)var define=require("requirejs").define;define("_cssparser",[],function(){"use strict";const e=function(e){var t=e.indexOf("<style>"),n=e.indexOf("</style>");return t!==-1&&e.substring(t+7,n)},t=function(e){if(e!==!1){var t=document.createElement("style"),n=document.head||document.getElementsByTagName("head")[0];t.type="text/css",t.styleSheet?t.styleSheet.cssText=e:t.appendChild(document.createTextNode(e)),n.appendChild(t)}};return{extractCss:e,appendCSSStyle:t,parse:function(n){const r=e(n);t(r)}}}),define("vue",["_cssparser"],function(e){return{load:function(t,n,r,s){var i,u;u=/.*(\.vue)|(\.html?)/.test(t)?"":".vue",i=n.toUrl(t+u);var a,c=["(function(template){","})("],f=function(e){var t=e.indexOf("<template>"),n=e.indexOf("</template>");return e.substring(t+10,n).replace(/([^\\])'/g,"$1\\'").replace(/[\n\r]+/g,"")},o=function(e){var t=e.indexOf("<script>"),n=e.indexOf("</script>");return e.substring(t+8,n)},d=function(t){var n=f(t),r=o(t);return s.isBuild||e.parse(t),c[0]+r+c[1]+"'"+n+"');"};if(s.isBuild){require("fs");a=function(e,t){var n=js.readFileSync().toString();t(d(n))}}else a=function(e,t){var n=new XMLHttpRequest;n.onreadystatechange=function(){4!==this.readyState||200!==this.status&&304!==this.status||t(d(n.responseText))},n.open("GET",e,!0),n.send()};n([],function(){a(i,function(e){r.fromText(e)})})}}}),define("require-vuejs",["vue"],function(e){return e});